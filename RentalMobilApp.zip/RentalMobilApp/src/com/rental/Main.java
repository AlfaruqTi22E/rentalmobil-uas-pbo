package com.rental;

import com.rental.gui.LoginForm;

import javax.swing.*;

/**
 * Titik masuk (entry point) Aplikasi Rental Mobil.
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
    }
}
