package com.rental.gui;

import com.rental.dao.MobilDAO;
import com.rental.dao.PelangganDAO;
import com.rental.dao.TransaksiDAO;
import com.rental.exception.MobilTidakTersediaException;
import com.rental.model.Mobil;
import com.rental.model.Pelanggan;
import com.rental.model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Panel untuk melakukan transaksi penyewaan mobil.
 * Memanggil TransaksiDAO yang di baliknya menjalankan STORED PROCEDURE
 * (yang memakai FUNCTION dan memicu TRIGGER di sisi database).
 */
public class TransaksiPanel extends JPanel {

    private final MobilDAO mobilDAO = new MobilDAO();
    private final PelangganDAO pelangganDAO = new PelangganDAO();
    private final TransaksiDAO transaksiDAO = new TransaksiDAO();
    private final User userAktif;

    private final JComboBox<Mobil> cbMobil = new JComboBox<>();
    private final JComboBox<Pelanggan> cbPelanggan = new JComboBox<>();
    private final JTextField txtTanggalSewa = new JTextField(LocalDate.now().toString(), 12);
    private final JTextField txtTanggalKembali = new JTextField(LocalDate.now().plusDays(1).toString(), 12);
    private final JTextField txtIdSelesai = new JTextField(8);

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;

    public TransaksiPanel(User userAktif) {
        this.userAktif = userAktif;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formSewa = new JPanel(new GridLayout(5, 2, 5, 5));
        formSewa.setBorder(BorderFactory.createTitledBorder("Buat Transaksi Penyewaan Baru"));
        formSewa.add(new JLabel("Mobil (hanya yang tersedia):"));
        formSewa.add(cbMobil);
        formSewa.add(new JLabel("Pelanggan:"));
        formSewa.add(cbPelanggan);
        formSewa.add(new JLabel("Tanggal Sewa (yyyy-mm-dd):"));
        formSewa.add(txtTanggalSewa);
        formSewa.add(new JLabel("Tanggal Kembali Rencana (yyyy-mm-dd):"));
        formSewa.add(txtTanggalKembali);

        JButton btnSewa = new JButton("Proses Penyewaan");
        formSewa.add(new JLabel());
        formSewa.add(btnSewa);

        JPanel formSelesai = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formSelesai.setBorder(BorderFactory.createTitledBorder("Selesaikan Transaksi (Mobil Dikembalikan)"));
        formSelesai.add(new JLabel("ID Transaksi:"));
        formSelesai.add(txtIdSelesai);
        JButton btnSelesai = new JButton("Tandai Selesai");
        formSelesai.add(btnSelesai);

        JButton btnMuatUlang = new JButton("Muat Ulang Daftar Mobil/Pelanggan");

        JPanel atas = new JPanel();
        atas.setLayout(new BoxLayout(atas, BoxLayout.Y_AXIS));
        atas.add(formSewa);
        atas.add(formSelesai);
        atas.add(btnMuatUlang);

        add(atas, BorderLayout.NORTH);

        JTextArea info = new JTextArea(
                "Petunjuk:\n"
              + "1. Pilih mobil (hanya mobil berstatus 'Tersedia' yang tampil) dan pelanggan, lalu isi tanggal.\n"
              + "2. Tekan 'Proses Penyewaan'. Sistem otomatis menghitung total biaya dan mengubah status mobil\n"
              + "   menjadi 'Disewa' melalui stored procedure & trigger di database.\n"
              + "3. Saat mobil kembali, masukkan ID Transaksi lalu tekan 'Tandai Selesai'. Status mobil otomatis\n"
              + "   kembali menjadi 'Tersedia'.\n"
              + "4. Lihat hasil lengkap di tab 'Laporan Penyewaan'."
        );
        info.setEditable(false);
        info.setBackground(getBackground());
        add(info, BorderLayout.CENTER);

        btnSewa.addActionListener(e -> prosesSewa());
        btnSelesai.addActionListener(e -> prosesSelesai());
        btnMuatUlang.addActionListener(e -> muatComboBox());

        muatComboBox();
    }

    private void muatComboBox() {
        cbMobil.removeAllItems();
        List<Mobil> daftarMobil = mobilDAO.semua();
        for (Mobil m : daftarMobil) {
            if (m.isTersedia()) {
                cbMobil.addItem(m);
            }
        }

        cbPelanggan.removeAllItems();
        List<Pelanggan> daftarPelanggan = pelangganDAO.semua();
        for (Pelanggan p : daftarPelanggan) {
            cbPelanggan.addItem(p);
        }
    }

    private void prosesSewa() {
        Mobil mobil = (Mobil) cbMobil.getSelectedItem();
        Pelanggan pelanggan = (Pelanggan) cbPelanggan.getSelectedItem();

        if (mobil == null || pelanggan == null) {
            JOptionPane.showMessageDialog(this, "Data mobil atau pelanggan belum tersedia. "
                    + "Tambahkan data terlebih dahulu pada tab terkait.");
            return;
        }

        try {
            LocalDate tglSewa = LocalDate.parse(txtTanggalSewa.getText().trim(), FORMAT);
            LocalDate tglKembali = LocalDate.parse(txtTanggalKembali.getText().trim(), FORMAT);

            if (!tglKembali.isAfter(tglSewa)) {
                JOptionPane.showMessageDialog(this, "Tanggal kembali rencana harus setelah tanggal sewa.",
                        "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            transaksiDAO.tambahTransaksi(mobil.getIdMobil(), pelanggan.getId(), userAktif.getId(),
                    Date.valueOf(tglSewa), Date.valueOf(tglKembali));

            JOptionPane.showMessageDialog(this, "Transaksi berhasil dibuat. Status mobil kini 'Disewa'.");
            muatComboBox();

        } catch (DateTimeParseException dpe) {
            JOptionPane.showMessageDialog(this, "Format tanggal harus yyyy-mm-dd, contoh: 2026-07-16.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
        } catch (MobilTidakTersediaException mte) {
            JOptionPane.showMessageDialog(this, mte.getMessage(), "Tidak Dapat Diproses", JOptionPane.ERROR_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void prosesSelesai() {
        String teksId = txtIdSelesai.getText().trim();
        if (teksId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan ID Transaksi yang ingin diselesaikan.");
            return;
        }
        try {
            int idTransaksi = Integer.parseInt(teksId);
            transaksiDAO.selesaikanTransaksi(idTransaksi, Date.valueOf(LocalDate.now()));
            JOptionPane.showMessageDialog(this, "Transaksi #" + idTransaksi + " ditandai selesai. "
                    + "Status mobil otomatis kembali 'Tersedia'.");
            txtIdSelesai.setText("");
            muatComboBox();
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "ID Transaksi harus berupa angka.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
