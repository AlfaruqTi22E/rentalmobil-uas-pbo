package com.rental.gui;

import com.rental.dao.PelangganDAO;
import com.rental.model.Pelanggan;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Panel CRUD dan pencarian data pelanggan.
 */
public class PelangganPanel extends JPanel {

    private final PelangganDAO pelangganDAO = new PelangganDAO();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Nama", "Alamat", "No. Telp", "No. KTP"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(model);

    private final JTextField txtNama = new JTextField(15);
    private final JTextField txtAlamat = new JTextField(20);
    private final JTextField txtTelp = new JTextField(12);
    private final JTextField txtKtp = new JTextField(18);
    private final JTextField txtCari = new JTextField(18);

    private int idTerpilih = -1;

    public PelangganPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(4, 2, 5, 5));
        form.add(new JLabel("Nama:")); form.add(txtNama);
        form.add(new JLabel("Alamat:")); form.add(txtAlamat);
        form.add(new JLabel("No. Telp:")); form.add(txtTelp);
        form.add(new JLabel("No. KTP:")); form.add(txtKtp);

        JButton btnTambah = new JButton("Tambah");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBersih = new JButton("Bersihkan");
        JButton btnCari = new JButton("Cari");

        JPanel tombol = new JPanel(new FlowLayout());
        tombol.add(btnTambah); tombol.add(btnUbah); tombol.add(btnHapus); tombol.add(btnBersih);

        JPanel pencarian = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pencarian.add(new JLabel("Cari (nama/KTP):"));
        pencarian.add(txtCari);
        pencarian.add(btnCari);

        JPanel atas = new JPanel();
        atas.setLayout(new BoxLayout(atas, BoxLayout.Y_AXIS));
        atas.add(pencarian);
        atas.add(form);
        atas.add(tombol);

        add(atas, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnTambah.addActionListener(e -> tambah());
        btnUbah.addActionListener(e -> ubah());
        btnHapus.addActionListener(e -> hapus());
        btnBersih.addActionListener(e -> bersihkanForm());
        btnCari.addActionListener(e -> muatData(txtCari.getText().trim()));

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                idTerpilih = (int) model.getValueAt(row, 0);
                txtNama.setText((String) model.getValueAt(row, 1));
                txtAlamat.setText((String) model.getValueAt(row, 2));
                txtTelp.setText((String) model.getValueAt(row, 3));
                txtKtp.setText((String) model.getValueAt(row, 4));
            }
        });

        muatData("");
    }

    private void muatData(String kataKunci) {
        model.setRowCount(0);
        try {
            for (Pelanggan p : pelangganDAO.cari(kataKunci)) {
                model.addRow(new Object[]{p.getId(), p.getNama(), p.getAlamat(), p.getNoTelp(), p.getNoKtp()});
            }
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void tambah() {
        if (!validasiForm()) return;
        try {
            Pelanggan p = new Pelanggan(0, txtNama.getText().trim(), txtAlamat.getText().trim(),
                    txtTelp.getText().trim(), txtKtp.getText().trim());
            pelangganDAO.tambah(p);
            muatData("");
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data pelanggan berhasil ditambahkan.");
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void ubah() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data pelanggan pada tabel terlebih dahulu.");
            return;
        }
        if (!validasiForm()) return;
        try {
            Pelanggan p = new Pelanggan(idTerpilih, txtNama.getText().trim(), txtAlamat.getText().trim(),
                    txtTelp.getText().trim(), txtKtp.getText().trim());
            pelangganDAO.ubah(p);
            muatData("");
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data pelanggan berhasil diubah.");
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void hapus() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data pelanggan pada tabel terlebih dahulu.");
            return;
        }
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?",
                "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                pelangganDAO.hapus(idTerpilih);
                muatData("");
                bersihkanForm();
            } catch (RuntimeException ex) {
                tampilkanError(ex);
            }
        }
    }

    private boolean validasiForm() {
        if (txtNama.getText().trim().isEmpty() || txtKtp.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama dan No. KTP wajib diisi.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void bersihkanForm() {
        idTerpilih = -1;
        txtNama.setText("");
        txtAlamat.setText("");
        txtTelp.setText("");
        txtKtp.setText("");
        table.clearSelection();
    }

    private void tampilkanError(Exception ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
