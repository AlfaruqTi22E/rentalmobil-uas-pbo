package com.rental.gui;

import com.rental.dao.UserDAO;
import com.rental.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Panel CRUD untuk data user (petugas/admin).
 */
public class UserPanel extends JPanel {

    private final UserDAO userDAO = new UserDAO();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Username", "Password", "Nama", "Role"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(model);

    private final JTextField txtUsername = new JTextField(15);
    private final JPasswordField txtPassword = new JPasswordField(15);
    private final JTextField txtNama = new JTextField(15);
    private final JComboBox<String> cbRole = new JComboBox<>(new String[]{"Admin", "Kasir"});

    private int idTerpilih = -1;

    public UserPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(5, 2, 5, 5));
        form.add(new JLabel("Username:")); form.add(txtUsername);
        form.add(new JLabel("Password:")); form.add(txtPassword);
        form.add(new JLabel("Nama:")); form.add(txtNama);
        form.add(new JLabel("Role:")); form.add(cbRole);

        JButton btnTambah = new JButton("Tambah");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBersih = new JButton("Bersihkan");

        JPanel tombol = new JPanel(new FlowLayout());
        tombol.add(btnTambah); tombol.add(btnUbah); tombol.add(btnHapus); tombol.add(btnBersih);

        JPanel atas = new JPanel(new BorderLayout());
        atas.add(form, BorderLayout.CENTER);
        atas.add(tombol, BorderLayout.SOUTH);

        add(atas, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnTambah.addActionListener(e -> tambah());
        btnUbah.addActionListener(e -> ubah());
        btnHapus.addActionListener(e -> hapus());
        btnBersih.addActionListener(e -> bersihkanForm());

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                idTerpilih = (int) model.getValueAt(row, 0);
                txtUsername.setText((String) model.getValueAt(row, 1));
                txtPassword.setText((String) model.getValueAt(row, 2));
                txtNama.setText((String) model.getValueAt(row, 3));
                cbRole.setSelectedItem(model.getValueAt(row, 4));
            }
        });

        muatData();
    }

    private void muatData() {
        model.setRowCount(0);
        try {
            for (User u : userDAO.semua()) {
                model.addRow(new Object[]{u.getId(), u.getUsername(), u.getPassword(), u.getNama(), u.getRole()});
            }
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void tambah() {
        if (!validasiForm()) return;
        try {
            User u = new User(0, txtUsername.getText().trim(),
                    new String(txtPassword.getPassword()), txtNama.getText().trim(),
                    (String) cbRole.getSelectedItem());
            userDAO.tambah(u);
            muatData();
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data user berhasil ditambahkan.");
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void ubah() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data user pada tabel terlebih dahulu.");
            return;
        }
        if (!validasiForm()) return;
        try {
            User u = new User(idTerpilih, txtUsername.getText().trim(),
                    new String(txtPassword.getPassword()), txtNama.getText().trim(),
                    (String) cbRole.getSelectedItem());
            userDAO.ubah(u);
            muatData();
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data user berhasil diubah.");
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void hapus() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data user pada tabel terlebih dahulu.");
            return;
        }
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?",
                "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                userDAO.hapus(idTerpilih);
                muatData();
                bersihkanForm();
            } catch (RuntimeException ex) {
                tampilkanError(ex);
            }
        }
    }

    private boolean validasiForm() {
        if (txtUsername.getText().trim().isEmpty() || txtNama.getText().trim().isEmpty()
                || txtPassword.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Username, password, dan nama wajib diisi.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void bersihkanForm() {
        idTerpilih = -1;
        txtUsername.setText("");
        txtPassword.setText("");
        txtNama.setText("");
        cbRole.setSelectedIndex(0);
        table.clearSelection();
    }

    private void tampilkanError(Exception ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
