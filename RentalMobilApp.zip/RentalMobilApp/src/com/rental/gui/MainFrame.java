package com.rental.gui;

import com.rental.model.User;

import javax.swing.*;
import java.awt.*;

/**
 * Jendela utama aplikasi setelah login berhasil.
 * Berisi tab untuk setiap fitur: User, Mobil, Pelanggan, Transaksi, Laporan.
 */
public class MainFrame extends JFrame {

    public MainFrame(User userAktif) {
        setTitle("Aplikasi Rental Mobil - Login sebagai " + userAktif.getNama() + " (" + userAktif.getRole() + ")");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 600);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        // Tab User hanya untuk Admin (contoh penerapan role/hak akses)
        if (userAktif.isAdmin()) {
            tabs.addTab("Data User", new UserPanel());
        }
        tabs.addTab("Data Mobil", new MobilPanel());
        tabs.addTab("Data Pelanggan", new PelangganPanel());
        tabs.addTab("Transaksi Penyewaan", new TransaksiPanel(userAktif));
        tabs.addTab("Laporan Penyewaan", new LaporanPanel());

        add(tabs, BorderLayout.CENTER);

        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.add(new JLabel("  Masuk sebagai: " + userAktif.getNama() + " | Role: " + userAktif.getRole()));
        add(statusBar, BorderLayout.SOUTH);
    }
}
