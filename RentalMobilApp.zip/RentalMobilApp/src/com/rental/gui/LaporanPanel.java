package com.rental.gui;

import com.rental.dao.TransaksiDAO;
import com.rental.model.Transaksi;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Panel Laporan Penyewaan - menampilkan data dari VIEW view_laporan_penyewaan.
 */
public class LaporanPanel extends JPanel {

    private final TransaksiDAO transaksiDAO = new TransaksiDAO();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID Transaksi", "Pelanggan", "Mobil", "Petugas", "Tanggal Sewa",
                    "Rencana Kembali", "Kembali Aktual", "Total Biaya", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(model);

    public LaporanPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnMuatUlang = new JButton("Muat Ulang Laporan");
        JPanel atas = new JPanel(new FlowLayout(FlowLayout.LEFT));
        atas.add(btnMuatUlang);

        add(atas, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnMuatUlang.addActionListener(e -> muatData());

        muatData();
    }

    private void muatData() {
        model.setRowCount(0);
        try {
            for (Transaksi t : transaksiDAO.laporanPenyewaan()) {
                model.addRow(new Object[]{
                        t.getIdTransaksi(),
                        t.getNamaPelanggan(),
                        t.getNamaMobil(),
                        t.getNamaPetugas(),
                        t.getTanggalSewa(),
                        t.getTanggalKembaliRencana(),
                        t.getTanggalKembaliAktual() == null ? "-" : t.getTanggalKembaliAktual(),
                        t.getTotalBiaya(),
                        t.getStatus()
                });
            }
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat laporan: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
