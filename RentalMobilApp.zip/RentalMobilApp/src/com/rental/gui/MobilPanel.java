package com.rental.gui;

import com.rental.dao.MobilDAO;
import com.rental.model.Mobil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Panel CRUD dan pencarian data mobil.
 */
public class MobilPanel extends JPanel {

    private final MobilDAO mobilDAO = new MobilDAO();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Merk", "Model", "Tahun", "Plat Nomor", "Harga Sewa/Hari", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(model);

    private final JTextField txtMerk = new JTextField(12);
    private final JTextField txtModel = new JTextField(12);
    private final JTextField txtTahun = new JTextField(6);
    private final JTextField txtPlat = new JTextField(10);
    private final JTextField txtHarga = new JTextField(10);
    private final JComboBox<String> cbStatus = new JComboBox<>(new String[]{"Tersedia", "Disewa"});
    private final JTextField txtCari = new JTextField(18);

    private int idTerpilih = -1;

    public MobilPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(6, 2, 5, 5));
        form.add(new JLabel("Merk:")); form.add(txtMerk);
        form.add(new JLabel("Model:")); form.add(txtModel);
        form.add(new JLabel("Tahun:")); form.add(txtTahun);
        form.add(new JLabel("Plat Nomor:")); form.add(txtPlat);
        form.add(new JLabel("Harga Sewa/Hari:")); form.add(txtHarga);
        form.add(new JLabel("Status:")); form.add(cbStatus);

        JButton btnTambah = new JButton("Tambah");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBersih = new JButton("Bersihkan");
        JButton btnCari = new JButton("Cari");

        JPanel tombol = new JPanel(new FlowLayout());
        tombol.add(btnTambah); tombol.add(btnUbah); tombol.add(btnHapus); tombol.add(btnBersih);

        JPanel pencarian = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pencarian.add(new JLabel("Cari (merk/model/plat):"));
        pencarian.add(txtCari);
        pencarian.add(btnCari);

        JPanel atas = new JPanel();
        atas.setLayout(new BoxLayout(atas, BoxLayout.Y_AXIS));
        atas.add(pencarian);
        atas.add(form);
        atas.add(tombol);

        add(atas, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnTambah.addActionListener(e -> tambah());
        btnUbah.addActionListener(e -> ubah());
        btnHapus.addActionListener(e -> hapus());
        btnBersih.addActionListener(e -> bersihkanForm());
        btnCari.addActionListener(e -> muatData(txtCari.getText().trim()));

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                idTerpilih = (int) model.getValueAt(row, 0);
                txtMerk.setText((String) model.getValueAt(row, 1));
                txtModel.setText((String) model.getValueAt(row, 2));
                txtTahun.setText(String.valueOf(model.getValueAt(row, 3)));
                txtPlat.setText((String) model.getValueAt(row, 4));
                txtHarga.setText(model.getValueAt(row, 5).toString());
                cbStatus.setSelectedItem(model.getValueAt(row, 6));
            }
        });

        muatData("");
    }

    private void muatData(String kataKunci) {
        model.setRowCount(0);
        try {
            for (Mobil m : mobilDAO.cari(kataKunci)) {
                model.addRow(new Object[]{m.getIdMobil(), m.getMerk(), m.getModel(), m.getTahun(),
                        m.getPlatNomor(), m.getHargaSewa(), m.getStatus()});
            }
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void tambah() {
        if (!validasiForm()) return;
        try {
            Mobil m = new Mobil(0, txtMerk.getText().trim(), txtModel.getText().trim(),
                    Integer.parseInt(txtTahun.getText().trim()), txtPlat.getText().trim(),
                    Double.parseDouble(txtHarga.getText().trim()), (String) cbStatus.getSelectedItem());
            mobilDAO.tambah(m);
            muatData("");
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data mobil berhasil ditambahkan.");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Tahun dan harga sewa harus berupa angka.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void ubah() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data mobil pada tabel terlebih dahulu.");
            return;
        }
        if (!validasiForm()) return;
        try {
            Mobil m = new Mobil(idTerpilih, txtMerk.getText().trim(), txtModel.getText().trim(),
                    Integer.parseInt(txtTahun.getText().trim()), txtPlat.getText().trim(),
                    Double.parseDouble(txtHarga.getText().trim()), (String) cbStatus.getSelectedItem());
            mobilDAO.ubah(m);
            muatData("");
            bersihkanForm();
            JOptionPane.showMessageDialog(this, "Data mobil berhasil diubah.");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Tahun dan harga sewa harus berupa angka.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            tampilkanError(ex);
        }
    }

    private void hapus() {
        if (idTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data mobil pada tabel terlebih dahulu.");
            return;
        }
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?",
                "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                mobilDAO.hapus(idTerpilih);
                muatData("");
                bersihkanForm();
            } catch (RuntimeException ex) {
                tampilkanError(ex);
            }
        }
    }

    private boolean validasiForm() {
        if (txtMerk.getText().trim().isEmpty() || txtModel.getText().trim().isEmpty()
                || txtPlat.getText().trim().isEmpty() || txtTahun.getText().trim().isEmpty()
                || txtHarga.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field wajib diisi.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void bersihkanForm() {
        idTerpilih = -1;
        txtMerk.setText("");
        txtModel.setText("");
        txtTahun.setText("");
        txtPlat.setText("");
        txtHarga.setText("");
        cbStatus.setSelectedIndex(0);
        table.clearSelection();
    }

    private void tampilkanError(Exception ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
