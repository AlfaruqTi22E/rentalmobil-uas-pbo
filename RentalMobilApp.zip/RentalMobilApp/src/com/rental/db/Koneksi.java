package com.rental.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Kelas utilitas untuk membuka koneksi JDBC ke database MySQL.
 * Sesuaikan URL, USER, dan PASSWORD dengan konfigurasi MySQL di komputer masing-masing.
 */
public class Koneksi {

    private static final String URL = "jdbc:mysql://localhost:3306/rental_mobil?useSSL=false&serverTimezone=Asia/Jakarta";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Mencegah instansiasi objek dari luar (utility class)
    private Koneksi() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL JDBC tidak ditemukan. "
                    + "Pastikan mysql-connector-j ada di classpath.", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
