package com.rental.model;

/**
 * Kelas abstrak Person sebagai superclass dari User dan Pelanggan.
 * Menunjukkan konsep INHERITANCE (diturunkan ke User & Pelanggan),
 * ENKAPSULASI (field private, akses lewat getter/setter),
 * dan POLIMORFISME (method tampilkanInfo() dioverride tiap subclass).
 */
public abstract class Person {

    private int id;
    private String nama;
    private String alamat;
    private String noTelp;

    public Person() {
    }

    public Person(int id, String nama, String alamat, String noTelp) {
        this.id = id;
        this.nama = nama;
        this.alamat = alamat;
        this.noTelp = noTelp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    /**
     * Method abstrak yang wajib diimplementasikan berbeda oleh setiap
     * subclass (User dan Pelanggan) -> contoh POLIMORFISME.
     */
    public abstract String tampilkanInfo();
}
