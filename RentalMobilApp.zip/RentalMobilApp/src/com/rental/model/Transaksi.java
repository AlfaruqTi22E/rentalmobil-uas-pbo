package com.rental.model;

import java.sql.Date;

/**
 * Kelas Transaksi - merepresentasikan satu transaksi penyewaan mobil.
 */
public class Transaksi {

    private int idTransaksi;
    private int idMobil;
    private int idPelanggan;
    private int idUser;

    // Field tambahan (hasil join, untuk ditampilkan di tabel/laporan)
    private String namaMobil;
    private String namaPelanggan;
    private String namaPetugas;

    private Date tanggalSewa;
    private Date tanggalKembaliRencana;
    private Date tanggalKembaliAktual;
    private double totalBiaya;
    private String status; // "Berjalan" atau "Selesai"

    public Transaksi() {
    }

    public int getIdTransaksi() {
        return idTransaksi;
    }

    public void setIdTransaksi(int idTransaksi) {
        this.idTransaksi = idTransaksi;
    }

    public int getIdMobil() {
        return idMobil;
    }

    public void setIdMobil(int idMobil) {
        this.idMobil = idMobil;
    }

    public int getIdPelanggan() {
        return idPelanggan;
    }

    public void setIdPelanggan(int idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getNamaMobil() {
        return namaMobil;
    }

    public void setNamaMobil(String namaMobil) {
        this.namaMobil = namaMobil;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public String getNamaPetugas() {
        return namaPetugas;
    }

    public void setNamaPetugas(String namaPetugas) {
        this.namaPetugas = namaPetugas;
    }

    public Date getTanggalSewa() {
        return tanggalSewa;
    }

    public void setTanggalSewa(Date tanggalSewa) {
        this.tanggalSewa = tanggalSewa;
    }

    public Date getTanggalKembaliRencana() {
        return tanggalKembaliRencana;
    }

    public void setTanggalKembaliRencana(Date tanggalKembaliRencana) {
        this.tanggalKembaliRencana = tanggalKembaliRencana;
    }

    public Date getTanggalKembaliAktual() {
        return tanggalKembaliAktual;
    }

    public void setTanggalKembaliAktual(Date tanggalKembaliAktual) {
        this.tanggalKembaliAktual = tanggalKembaliAktual;
    }

    public double getTotalBiaya() {
        return totalBiaya;
    }

    public void setTotalBiaya(double totalBiaya) {
        this.totalBiaya = totalBiaya;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
