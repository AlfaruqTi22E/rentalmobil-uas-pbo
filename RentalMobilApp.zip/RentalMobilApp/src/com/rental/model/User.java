package com.rental.model;

/**
 * Kelas User (petugas / admin) - subclass dari Person.
 */
public class User extends Person {

    private String username;
    private String password;
    private String role; // "Admin" atau "Kasir"

    public User() {
        super();
    }

    public User(int id, String username, String password, String nama, String role) {
        super(id, nama, null, null);
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isAdmin() {
        return "Admin".equalsIgnoreCase(role);
    }

    @Override
    public String tampilkanInfo() {
        return "User #" + getId() + " - " + getNama() + " (" + username + ") - Role: " + role;
    }
}
