package com.rental.model;

/**
 * Kelas Mobil - merepresentasikan data kendaraan yang disewakan.
 * Menunjukkan konsep ENKAPSULASI: field private dengan getter/setter.
 */
public class Mobil {

    private int idMobil;
    private String merk;
    private String model;
    private int tahun;
    private String platNomor;
    private double hargaSewa;
    private String status; // "Tersedia" atau "Disewa"

    public Mobil() {
    }

    public Mobil(int idMobil, String merk, String model, int tahun,
                 String platNomor, double hargaSewa, String status) {
        this.idMobil = idMobil;
        this.merk = merk;
        this.model = model;
        this.tahun = tahun;
        this.platNomor = platNomor;
        this.hargaSewa = hargaSewa;
        this.status = status;
    }

    public int getIdMobil() {
        return idMobil;
    }

    public void setIdMobil(int idMobil) {
        this.idMobil = idMobil;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public String getPlatNomor() {
        return platNomor;
    }

    public void setPlatNomor(String platNomor) {
        this.platNomor = platNomor;
    }

    public double getHargaSewa() {
        return hargaSewa;
    }

    public void setHargaSewa(double hargaSewa) {
        this.hargaSewa = hargaSewa;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isTersedia() {
        return "Tersedia".equalsIgnoreCase(status);
    }

    @Override
    public String toString() {
        return merk + " " + model + " (" + platNomor + ")";
    }
}
