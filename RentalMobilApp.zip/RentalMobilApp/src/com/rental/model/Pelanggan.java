package com.rental.model;

/**
 * Kelas Pelanggan - subclass dari Person.
 */
public class Pelanggan extends Person {

    private String noKtp;

    public Pelanggan() {
        super();
    }

    public Pelanggan(int id, String nama, String alamat, String noTelp, String noKtp) {
        super(id, nama, alamat, noTelp);
        this.noKtp = noKtp;
    }

    public String getNoKtp() {
        return noKtp;
    }

    public void setNoKtp(String noKtp) {
        this.noKtp = noKtp;
    }

    @Override
    public String tampilkanInfo() {
        return "Pelanggan #" + getId() + " - " + getNama() + " - KTP: " + noKtp;
    }
}
