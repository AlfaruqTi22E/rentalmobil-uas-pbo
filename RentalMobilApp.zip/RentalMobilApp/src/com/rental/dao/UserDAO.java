package com.rental.dao;

import com.rental.db.Koneksi;
import com.rental.exception.DataTidakDitemukanException;
import com.rental.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object untuk tabel users.
 * Menangani operasi login dan CRUD data user (petugas/admin).
 */
public class UserDAO {

    public User login(String username, String password) throws DataTidakDitemukanException {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                } else {
                    throw new DataTidakDitemukanException("Username atau password salah.");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal terhubung ke database: " + e.getMessage(), e);
        }
    }

    public void tambah(User user) {
        String sql = "INSERT INTO users (username, password, nama, role) VALUES (?, ?, ?, ?)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getNama());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menambah user: " + e.getMessage(), e);
        }
    }

    public void ubah(User user) {
        String sql = "UPDATE users SET username=?, password=?, nama=?, role=? WHERE id_user=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getNama());
            ps.setString(4, user.getRole());
            ps.setInt(5, user.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mengubah user: " + e.getMessage(), e);
        }
    }

    public void hapus(int idUser) {
        String sql = "DELETE FROM users WHERE id_user=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUser);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menghapus user: " + e.getMessage(), e);
        }
    }

    public List<User> semua() {
        List<User> daftar = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY id_user";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                daftar.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mengambil data user: " + e.getMessage(), e);
        }
        return daftar;
    }

    private User mapRow(ResultSet rs) throws SQLException {
        return new User(
                rs.getInt("id_user"),
                rs.getString("username"),
                rs.getString("password"),
                rs.getString("nama"),
                rs.getString("role")
        );
    }
}
