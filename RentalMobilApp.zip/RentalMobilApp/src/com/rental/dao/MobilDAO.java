package com.rental.dao;

import com.rental.db.Koneksi;
import com.rental.exception.DataTidakDitemukanException;
import com.rental.model.Mobil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object untuk tabel mobil.
 * Menyediakan operasi CRUD dan pencarian data mobil.
 */
public class MobilDAO {

    public void tambah(Mobil mobil) {
        String sql = "INSERT INTO mobil (merk, model, tahun, plat_nomor, harga_sewa, status) VALUES (?,?,?,?,?,?)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mobil.getMerk());
            ps.setString(2, mobil.getModel());
            ps.setInt(3, mobil.getTahun());
            ps.setString(4, mobil.getPlatNomor());
            ps.setDouble(5, mobil.getHargaSewa());
            ps.setString(6, mobil.getStatus());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menambah data mobil: " + e.getMessage(), e);
        }
    }

    public void ubah(Mobil mobil) {
        String sql = "UPDATE mobil SET merk=?, model=?, tahun=?, plat_nomor=?, harga_sewa=?, status=? WHERE id_mobil=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mobil.getMerk());
            ps.setString(2, mobil.getModel());
            ps.setInt(3, mobil.getTahun());
            ps.setString(4, mobil.getPlatNomor());
            ps.setDouble(5, mobil.getHargaSewa());
            ps.setString(6, mobil.getStatus());
            ps.setInt(7, mobil.getIdMobil());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mengubah data mobil: " + e.getMessage(), e);
        }
    }

    public void hapus(int idMobil) {
        String sql = "DELETE FROM mobil WHERE id_mobil=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idMobil);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menghapus data mobil: " + e.getMessage(), e);
        }
    }

    public Mobil cariById(int idMobil) throws DataTidakDitemukanException {
        String sql = "SELECT * FROM mobil WHERE id_mobil = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idMobil);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                } else {
                    throw new DataTidakDitemukanException("Mobil dengan ID " + idMobil + " tidak ditemukan.");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mencari data mobil: " + e.getMessage(), e);
        }
    }

    /** Pencarian mobil berdasarkan kata kunci (merk, model, atau plat nomor). */
    public List<Mobil> cari(String kataKunci) {
        List<Mobil> daftar = new ArrayList<>();
        String sql = "SELECT * FROM mobil WHERE merk LIKE ? OR model LIKE ? OR plat_nomor LIKE ? ORDER BY id_mobil";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String pola = "%" + kataKunci + "%";
            ps.setString(1, pola);
            ps.setString(2, pola);
            ps.setString(3, pola);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    daftar.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mencari data mobil: " + e.getMessage(), e);
        }
        return daftar;
    }

    public List<Mobil> semua() {
        return cari("");
    }

    private Mobil mapRow(ResultSet rs) throws SQLException {
        return new Mobil(
                rs.getInt("id_mobil"),
                rs.getString("merk"),
                rs.getString("model"),
                rs.getInt("tahun"),
                rs.getString("plat_nomor"),
                rs.getDouble("harga_sewa"),
                rs.getString("status")
        );
    }
}
