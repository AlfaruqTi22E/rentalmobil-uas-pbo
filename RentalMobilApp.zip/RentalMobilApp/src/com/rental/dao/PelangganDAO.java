package com.rental.dao;

import com.rental.db.Koneksi;
import com.rental.exception.DataTidakDitemukanException;
import com.rental.model.Pelanggan;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object untuk tabel pelanggan.
 */
public class PelangganDAO {

    public void tambah(Pelanggan p) {
        String sql = "INSERT INTO pelanggan (nama, alamat, no_telp, no_ktp) VALUES (?,?,?,?)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, p.getNama());
            ps.setString(2, p.getAlamat());
            ps.setString(3, p.getNoTelp());
            ps.setString(4, p.getNoKtp());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menambah data pelanggan: " + e.getMessage(), e);
        }
    }

    public void ubah(Pelanggan p) {
        String sql = "UPDATE pelanggan SET nama=?, alamat=?, no_telp=?, no_ktp=? WHERE id_pelanggan=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, p.getNama());
            ps.setString(2, p.getAlamat());
            ps.setString(3, p.getNoTelp());
            ps.setString(4, p.getNoKtp());
            ps.setInt(5, p.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mengubah data pelanggan: " + e.getMessage(), e);
        }
    }

    public void hapus(int idPelanggan) {
        String sql = "DELETE FROM pelanggan WHERE id_pelanggan=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idPelanggan);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menghapus data pelanggan: " + e.getMessage(), e);
        }
    }

    public Pelanggan cariById(int idPelanggan) throws DataTidakDitemukanException {
        String sql = "SELECT * FROM pelanggan WHERE id_pelanggan = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idPelanggan);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                } else {
                    throw new DataTidakDitemukanException("Pelanggan dengan ID " + idPelanggan + " tidak ditemukan.");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mencari data pelanggan: " + e.getMessage(), e);
        }
    }

    /** Pencarian pelanggan berdasarkan nama atau no. KTP. */
    public List<Pelanggan> cari(String kataKunci) {
        List<Pelanggan> daftar = new ArrayList<>();
        String sql = "SELECT * FROM pelanggan WHERE nama LIKE ? OR no_ktp LIKE ? ORDER BY id_pelanggan";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String pola = "%" + kataKunci + "%";
            ps.setString(1, pola);
            ps.setString(2, pola);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    daftar.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mencari data pelanggan: " + e.getMessage(), e);
        }
        return daftar;
    }

    public List<Pelanggan> semua() {
        return cari("");
    }

    private Pelanggan mapRow(ResultSet rs) throws SQLException {
        return new Pelanggan(
                rs.getInt("id_pelanggan"),
                rs.getString("nama"),
                rs.getString("alamat"),
                rs.getString("no_telp"),
                rs.getString("no_ktp")
        );
    }
}
