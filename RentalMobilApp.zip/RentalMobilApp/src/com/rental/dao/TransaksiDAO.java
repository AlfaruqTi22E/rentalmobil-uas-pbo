package com.rental.dao;

import com.rental.db.Koneksi;
import com.rental.exception.MobilTidakTersediaException;
import com.rental.model.Transaksi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object untuk transaksi penyewaan.
 * - tambahTransaksi() memanggil STORED PROCEDURE sp_tambah_transaksi
 *   (yang di dalamnya memakai FUNCTION fn_hitung_biaya dan memicu TRIGGER
 *   untuk mengubah status mobil secara otomatis).
 * - laporanPenyewaan() membaca dari VIEW view_laporan_penyewaan.
 */
public class TransaksiDAO {

    /** Membuat transaksi baru lewat stored procedure di database. */
    public void tambahTransaksi(int idMobil, int idPelanggan, int idUser,
                                 Date tanggalSewa, Date tanggalKembaliRencana)
            throws MobilTidakTersediaException {

        String sql = "{CALL sp_tambah_transaksi(?, ?, ?, ?, ?)}";
        try (Connection conn = Koneksi.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setInt(1, idMobil);
            cs.setInt(2, idPelanggan);
            cs.setInt(3, idUser);
            cs.setDate(4, tanggalSewa);
            cs.setDate(5, tanggalKembaliRencana);
            cs.execute();

        } catch (SQLException e) {
            // SIGNAL SQLSTATE '45000' dari stored procedure ditangkap di sini
            if (e.getSQLState() != null && e.getSQLState().equals("45000")) {
                throw new MobilTidakTersediaException(e.getMessage());
            }
            throw new RuntimeException("Gagal membuat transaksi: " + e.getMessage(), e);
        }
    }

    /** Menandai transaksi selesai (mobil dikembalikan). Trigger akan mengubah status mobil. */
    public void selesaikanTransaksi(int idTransaksi, Date tanggalKembaliAktual) {
        String sql = "UPDATE transaksi SET status='Selesai', tanggal_kembali_aktual=? WHERE id_transaksi=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, tanggalKembaliAktual);
            ps.setInt(2, idTransaksi);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Gagal menyelesaikan transaksi: " + e.getMessage(), e);
        }
    }

    /** Mengambil seluruh laporan penyewaan dari VIEW view_laporan_penyewaan. */
    public List<Transaksi> laporanPenyewaan() {
        List<Transaksi> daftar = new ArrayList<>();
        String sql = "SELECT * FROM view_laporan_penyewaan";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Transaksi t = new Transaksi();
                t.setIdTransaksi(rs.getInt("id_transaksi"));
                t.setNamaPelanggan(rs.getString("nama_pelanggan"));
                t.setNamaMobil(rs.getString("merk") + " " + rs.getString("model")
                        + " (" + rs.getString("plat_nomor") + ")");
                t.setNamaPetugas(rs.getString("petugas"));
                t.setTanggalSewa(rs.getDate("tanggal_sewa"));
                t.setTanggalKembaliRencana(rs.getDate("tanggal_kembali_rencana"));
                t.setTanggalKembaliAktual(rs.getDate("tanggal_kembali_aktual"));
                t.setTotalBiaya(rs.getDouble("total_biaya"));
                t.setStatus(rs.getString("status"));
                daftar.add(t);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Gagal mengambil laporan penyewaan: " + e.getMessage(), e);
        }
        return daftar;
    }
}
