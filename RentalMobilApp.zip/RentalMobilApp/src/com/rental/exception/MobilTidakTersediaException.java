package com.rental.exception;

/**
 * Exception khusus yang dilempar ketika mobil yang ingin disewa
 * ternyata berstatus sedang disewa (tidak tersedia).
 */
public class MobilTidakTersediaException extends Exception {

    public MobilTidakTersediaException(String pesan) {
        super(pesan);
    }
}
