package com.rental.exception;

/**
 * Exception khusus (checked exception) yang dilempar ketika data
 * yang dicari (mobil, pelanggan, user, transaksi) tidak ditemukan di database.
 */
public class DataTidakDitemukanException extends Exception {

    public DataTidakDitemukanException(String pesan) {
        super(pesan);
    }
}
