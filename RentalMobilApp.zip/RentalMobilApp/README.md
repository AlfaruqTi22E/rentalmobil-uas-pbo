# Aplikasi Rental Mobil (Java Swing + MySQL)

Aplikasi desktop untuk mengelola data kendaraan, pelanggan, dan transaksi
penyewaan mobil. Dibangun dengan Java Swing (GUI), JDBC (koneksi database),
dan MySQL (database), menerapkan konsep PBO: class, object, enkapsulasi,
inheritance, polimorfisme, package, dan exception handling.

## Struktur Proyek

```
RentalMobilApp/
├── database/
│   └── rental_mobil.sql        <- schema + stored procedure + function + trigger + view
├── src/com/rental/
│   ├── Main.java                <- entry point
│   ├── db/Koneksi.java          <- koneksi JDBC
│   ├── exception/               <- custom exceptions
│   ├── model/                   <- Person (abstract), User, Pelanggan, Mobil, Transaksi
│   ├── dao/                     <- UserDAO, MobilDAO, PelangganDAO, TransaksiDAO
│   └── gui/                     <- LoginForm, MainFrame, dan panel tiap fitur
└── README.md
```

## Fitur

- Login (autentikasi terhadap tabel `users`)
- CRUD Data User (khusus role Admin)
- CRUD Data Mobil + Pencarian
- CRUD Data Pelanggan + Pencarian
- Transaksi Penyewaan (memanggil stored procedure, otomatis hitung biaya & ubah status mobil lewat trigger)
- Laporan Penyewaan (dari database view)

## Konsep PBO yang Diterapkan

| Konsep | Lokasi |
|---|---|
| Class & Object | Semua kelas di `model`, `dao`, `gui` |
| Enkapsulasi | Field `private` + getter/setter di semua model |
| Inheritance | `User` dan `Pelanggan` extends `Person` |
| Polimorfisme | Method `tampilkanInfo()` di-override berbeda di `User` & `Pelanggan` |
| Package | `db`, `exception`, `model`, `dao`, `gui` |
| Exception Handling | `DataTidakDitemukanException`, `MobilTidakTersediaException`, try-catch di semua DAO/GUI |

## Konsep Database yang Diterapkan

| Objek | Nama | Fungsi |
|---|---|---|
| Stored Procedure | `sp_tambah_transaksi` | Membuat transaksi baru, validasi status mobil |
| Function | `fn_hitung_biaya` | Menghitung total biaya sewa (jumlah hari x harga) |
| Trigger | `trg_after_insert_transaksi` | Set status mobil jadi 'Disewa' otomatis setelah transaksi dibuat |
| Trigger | `trg_after_update_transaksi` | Set status mobil jadi 'Tersedia' otomatis saat transaksi selesai |
| View | `view_laporan_penyewaan` | Join transaksi + mobil + pelanggan + user untuk laporan |

## Cara Menjalankan

### 1. Siapkan Database

1. Buka MySQL (Workbench / CLI / phpMyAdmin).
2. Jalankan seluruh isi file `database/rental_mobil.sql`. Ini akan membuat
   database `rental_mobil`, seluruh tabel, data awal, function, stored
   procedure, trigger, dan view.

### 2. Siapkan Driver JDBC

Unduh **MySQL Connector/J** (`mysql-connector-j-x.x.x.jar`) dari situs resmi
MySQL, lalu tambahkan sebagai library/classpath di IDE (NetBeans/IntelliJ/Eclipse)
atau via terminal.

### 3. Sesuaikan Konfigurasi Koneksi

Buka `src/com/rental/db/Koneksi.java` dan sesuaikan `USER` dan `PASSWORD`
dengan akun MySQL di komputer Anda (default: user `root`, password kosong).

### 4. Compile & Jalankan (via terminal)

```bash
# dari folder RentalMobilApp
javac -d out -cp "src;mysql-connector-j-8.x.x.jar" $(find src -name "*.java")   # Windows: gunakan ; | Linux/Mac: gunakan :
java -cp "out;mysql-connector-j-8.x.x.jar" com.rental.Main
```

Atau, lebih mudah: buka proyek ini di NetBeans/IntelliJ/Eclipse, tambahkan
`mysql-connector-j` sebagai library, lalu jalankan `Main.java`.

### 5. Login

Akun default (dari data awal di `rental_mobil.sql`):

| Username | Password | Role |
|---|---|---|
| admin | admin123 | Admin |
| kasir1 | kasir123 | Kasir |

## Catatan

- Tab **Data User** hanya muncul untuk akun dengan role **Admin**.
- Saat membuat transaksi, hanya mobil berstatus **Tersedia** yang muncul di
  daftar pilihan — begitu transaksi dibuat, trigger database otomatis
  mengubah status mobil menjadi **Disewa**.
- Tombol **"Tandai Selesai"** di tab Transaksi akan mengubah status
  transaksi menjadi **Selesai** dan trigger otomatis mengembalikan status
  mobil menjadi **Tersedia**.
